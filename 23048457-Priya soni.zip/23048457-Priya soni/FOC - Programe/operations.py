from read import show_land_data,read_land_data,read_land_duration
from miscallaneous import greet_user
from write import write_bill

def return_operation():
    # Read land data from the database
    data = read_land_data()

    # Ask the user for their name
    user_name = ''
    while True:
        user_name = input("Enter your Name: ")
        if len(user_name) > 0:
            break
        else:
            print("\nPlease Enter a valid name!\n")

    # Ask the user for their phone number
    user_number = 0
    while True: 
        try: 
            user_number = int(input("Enter your phone number: "))
            if user_number <= 0 or len(str(user_number)) != 10:
                raise ValueError
            break
        except ValueError:
            print("\nPlease enter a valid 10-digit phone number!\n")

    # Display the land data to the user
    show_land_data()

    # initialize two empty list to store rented lands
    selected_lands = []
    returned_lands = []

    '''
    This loop will run continuously until the user selects a land to return.
    After the user selects a land, it will ask if they want to return another land. 
    If the user wants to return another land, the loop runs again; otherwise, it generates the invoice.
    ''' 
    while True:
        # Initialize required variables
        kitta = 0
        duration = 0

        try:
            # get kitta from the user
            kitta = int(input("Enter a kitta number: "))
            
            # validating if the entered kitta exists in the database
            if kitta not in data:
                print("\nPlease Enter a valid kitta number\n")
                continue

            # validating if the status of the selected land rented or not
            if data[kitta]['status'] == 'Available':
                print("\nThe selected land is not currently rented.\n")
                continue

            # Validate if the land has already been selected 
            if kitta in returned_lands:
                print("\nYou have already selected this land for return.\n")
                continue

            # Ask the user for the duration of the previous rent
            duration = int(input("Enter the duration of previous rent (in months): "))
            if duration <= 0 or duration > 100:
                print("\nEnter a valid duration\n")
                continue

            # Prepare data for the selected land and add it to the list
            selected_land = data[kitta].copy()
            selected_land['kitta'] = kitta
            selected_land['duration'] = duration
            selected_lands.append(selected_land)
            returned_lands.append(kitta)

            # Ask the user if they want to return another land
            exit_query = input("Do you want to add more land? (y/n): ").lower()
            if exit_query != 'y':
                break  

        except ValueError:
            print("\nPlease Enter a valid number\n")


    # call the write bill function with required parameters.
    write_bill('return', selected_lands, user_name, user_number)

    # Update the rented land durations in the database
    land_durations = read_land_duration()
    for kitta in returned_lands: # [101]
        if str(kitta) in land_durations:
            # delete the data
            # data = {'102':2}

            del land_durations[str(kitta)]

    # Write the updated land durations to the file
    with open('durations.txt', 'w') as file:
        for kitta, duration in land_durations.items():
            file.write(kitta + "," + str(duration) + "\n")

    # Wait for user input before continuing
    input('Press ENTER key to continue...')
    greet_user()

"""
 |  
 |  
 |  
 |  
 |  
"""

def rent_operation():
    # read the data from the user
    data = read_land_data()

    # Ask the user for their name 
    user_name = ''  
    while True:
        user_name = input("Enter your Name: ")

        if len(user_name) > 0:
            break

        else:
            print("\nPlease Enter a valid name!\n")

    
    # Ask the user for their number
    user_number = 0
    while True: 
        try: 
             user_number = int(input("Enter your phone number: "))  
             
             if user_number <= 0 or len(str(user_number)) != 10:
                 raise ValueError

             break
        except ValueError:
            print("\nPlease enter a valid 10 digit user number!\n")

    # Display the land data to the user. 
    show_land_data()

    # initialize two empty list to store rented lands
    selected_lands = []  
    rented_lands = [] 

    
    '''
    This loop will run continously till the user selects a land.
    after the user selects a land it will ask the user if they want to add another land. 
    if the user wants to rent another land, it will run the loop again, else will generate the invoice
    ''' 
    while True:
        # initialize the required variables
        kitta = 0
        anna = 0
        duration = 0

        try:
            # get kitta from the user
            kitta = int(input("Enter a kitta number: "))

            # validating if the entered kitta exists in the database
            if kitta not in data:
                print("\nPlease Enter a valid kitta number\n")
                continue # Restart the loop  

            # validating if the status of the selected land is available
            if data[kitta]['status'] != 'Available':
                print("\nThe selected land is not available for rent.\n")
                continue # Restart the loop   
            
            '''
            validating the user has already selected a land.
            Only works from the second iteration
            '''
            if kitta in rented_lands:
                print("\nYou have already rented this land.\n")
                continue # Restart the loop 
            
            anna = int(input("Enter annas you want to rent: "))
            # Validate if the entered anna is equal to the anna of land
            if anna != data[kitta]['anna']:
                print("\nThe entered anna should be equal to land anna\n")
                continue # Restart the loop   
            
            # Ask the user for the duration they want yo rent
            duration = int(input("Enter the duration (in months) you want to rent for: "))
            if duration <= 0:
                print("\nEnter a valid duration \n") 
                continue # Restart the loop 
            elif duration > 100:
                print("\nYou cannot rent for more than 100 months. \n") 
                continue # Restart the loop 

            selected_land = data[kitta].copy()  
            selected_land['kitta'] = kitta 
            selected_land['duration'] = duration  
            selected_lands.append(selected_land) 
            rented_lands.append(kitta) 

            # ask the user if they want to exit the program 
            exit_query = input("Do you want to add more land? (y/n): ").lower()
            if exit_query != 'y':
                break  

        except ValueError:
            print("\nPlease Enter a valid number\n")


    # writing the rented months in a seperate file
    with open('durations.txt',"a") as file:
        for land in selected_lands:
            kitta = str(land['kitta'])
            duration = str(land['duration'])
            file.write(kitta + "," +duration + "\n")

    # call the write method with required parameters to generate a bill 
    write_bill('rent', selected_lands, user_name, user_number)

    input('Press ENTER key to continue...')
    greet_user()