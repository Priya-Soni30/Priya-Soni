import datetime

def greet_user():
    """
    The greet_user function will show the greeting message in a proper foramt
    """
    print("=" * 52)
    print("*" + " " * 14 + "TECHNO PROPERTY NEPAL" + " " * 15 + "*" )
    print("*" + " " * 17 + "Kathmandu, Nepal" + " " * 17 + "*" )
    print("*" + " " * 11 + "Contact : 01-4450000 4450001" + " " * 11 + "*") 
    print("=" * 52)
    print("*  1 ---> Rent   " + " " * 34 + "*")
    print("*  2 ---> Return " + " " * 34 + "*")
    print("*  3 ---> Exit   " + " " * 34 + "*")
    print("=" * 52)

def goodbye():
    """
    The goodbye function will show the goodbye message in a proper foramt
    """
    print("\n" * 3)
    print("=" * 52)
    print("*" + " " * 14 + "TECHNO PROPERTY NEPAL" + " " * 15 + "*" )
    print("*" + " " * 17 + "Kathmandu, Nepal" + " " * 17 + "*" )
    print("*" + " " * 11 + "Contact : 01-4450000 4450001" + " " * 11 + "*") 
    print("=" * 52)
    print("*" + " " * 10 + "THANKYOU FOR USING OUR SYSTEM!" + " " * 10 + "*" )
    print("=" * 52)
    print("\n" * 3)


def generate_unique_filename(mode,name, number):
    date_time = datetime.datetime.now()

    date = str(date_time).split(" ")[0]

    hr = date_time.hour
    min = date_time.minute

    name = name.replace(' ', "-")

    file =  "BILL-" + mode + name + "-" + str(number) + "_" + date + "_" + str(hr) + "-" + str(min) + ".txt"
    
    return file