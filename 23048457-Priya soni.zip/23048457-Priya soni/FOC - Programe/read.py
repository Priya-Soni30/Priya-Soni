def read_land_data():
    '''
    The read_land_data function reads the data from the main file.
    It will return the data in a dictionary.
    '''
    output = {}
    '''
        105,Biratnagar,West,3,16000.0,Available
        { key : value }

        retrn = {
            105: {
            "city" : biratnagar,
            "direction" : west,
            ...
            },
            106: {
            "city" : biratnagar,
            "direction" : west,
            ...
            }
        }
    '''
    try:
        # Open the data.txt file in read mode
        with open("data.txt", 'r') as file:
            # iterate over all lines in a file
            for line in file:
                '''
                remove the line break (\n) from each line and splt by ',' 
                this will make the line variable into a list
                '''
                '''
                101,Kathmandu,North,4,50000.0,Available\n
                          0         1        2       3   4          5 
                line = ["101","Kathmandu","North","4","50000.0", 'Available']
                '''
                line = line.replace("\n", '').split(',')

                '''
                key , value
                
                line[0]
                line[1]

                output[int(line[0])] = {
                    'city': line[1]
                }
                arr[0]
                dur['key']
                '''
                # make the dictionary with key as kitta and other values 
                output[ int(line[0]) ] = {
                    'city': line[1],
                    'direction': line[2],
                    'anna': int(line[3]),
                    'price': float(line[4]),
                    'status': line[5]
                }
    # print an error if file is not found
    except FileNotFoundError:
        print("File not found.")

    return output


# 

def read_land_duration():
    '''
    The read_land_duration function wil read the duration of rented from the durations.txt file
    it will return the land_durations in a dictionary format
    '''

    # initialize an empty dictionary 
    land_durations = {}
    # open the durations.txt file in read mode
    with open('durations.txt', 'r') as file:
        for line in file:
            '''
            101,2
            data = {'101':2}

            ['101','2']
            remove the line break (\n) from each line and splt by ',' 
            take the kitta and duration and store it in required variables
            '''
            kitta, duration = line.replace('\n','').split(',')

            # add the data to land_durations dictionary with key kitta and value duration
            land_durations[kitta] = int(duration)

    return land_durations

def show_land_data():
    """
    The show_land_data will show the data from the file in a properly formatted way
    """

    # read the data from the file
    data = read_land_data()

    print("=" * 78)
    print("| Kitta_number | " + "City" + " " * 10 + " | "  + "Direction " + " | "  + "Anna " + " | "  + "Price" + " " * 5 + " | "  + "Status" + " " * 9 + " | ")
    print("=" * 78)

    # print each line in a proper format
    for kitta, land_details in data.items():
        print("| " + 
            str(kitta) + " " * (12 - len(str(kitta))) + " | " + 
            land_details['city'] + " " * (14 - len(land_details['city'])) + " | " + 
            land_details['direction'] + " " * (10 - len(land_details['direction'])) + " | " + 
            str(land_details['anna']) + " " * (5 - len(str(land_details['anna']))) + " | " + 
            str(land_details['price']) + " " * (10 - len(str(land_details['price']))) + " | " + 
            land_details['status'] + " " * (16 - len(land_details['status'])) + "|"
        )
    print("=" * 78)
