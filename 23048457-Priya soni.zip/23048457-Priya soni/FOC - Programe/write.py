from read import read_land_data,read_land_duration
from miscallaneous import generate_unique_filename

def write_bill(mode, selected_lands, customer_name, customer_number):
    # rent or return

    update_main_database(mode, selected_lands)
    
    total_amount = 0.0
    total_fine = 0.0
    duration_rate = 10 # if late 10 % 

    output_string = "\n"
    output_string += "=" * 92 + "\n"
    output_string += "*" + " " * 34 + "TECHNO PROPERTY NEPAL" + " " * 35 + "*" + "\n"
    output_string += "*" + " " * 37 + "Kathmandu, Nepal" + " " * 37 + "*" + "\n"
    output_string += "*" + " " * 31 + "Contact : 01-4450000 4450001" + " " * 31 + "*" + "\n"
    output_string += "=" * 92 + "\n"
    output_string += (
        mode + "ed by: " + customer_name + 

        " " * (60 - len(customer_name)) + 

        "Contact: " + str(customer_number) + "\n"
    )

    output_string += "=" * 92 + "\n"

    output_string += (
        "Kitta_number" + " | " +
        "City " + " " * 8 +  " | " +
        "Direction" +  " | " +
        "Anna" +  " | " + 
        "Duration" +  " | " + 
        "Price" + " " * 8 +  " | " + 
        "Fine" + " " * 4 + " | " + 
        "Total" + " " * 8 + "\n"
    )
    output_string += "=" * 92 + "\n"
    

    for land in selected_lands:
        kitta = str(land['kitta'])
        city = land['city']
        direction = land['direction']
        anna = str(land['anna'])
        price = str(land['price'])
        used_duration = str(land['duration'])

        fine = 0

        total = land['price'] * land['duration']
    
        if mode == 'return':
            duration_data = read_land_duration()

            if kitta in duration_data:
                rented_duration = duration_data[kitta]
                #             6     >       4         
                if land['duration'] > rented_duration:
                    extra_duration = land['duration'] - rented_duration
                    # 6 - 4
                    # 2
                    # 1029.2939485859080398034
                    # 1029.29
                    fine = round(extra_duration * (duration_rate / 100) * land['price'], 2)
                    total_fine += fine

        total += fine

        output_string += (
            str(kitta) + "   | " + 
            city + " " * (18 - len(city)) + " | " + 
            direction + " " * (9 - len(direction)) + " | " + 
            anna + " " * (5 - len(anna)) + " | " + 
            used_duration + " " * (7 - len(used_duration)) + " | " + 
            price + " " * (13 - len(price)) + " | " + 
            str(fine) + " " * (8 - len(str(fine))) + " | " + 
            str(total) + "\n"
        )

        total_amount += total

    final_total = total_fine + total_amount
    
    output_string += "=" * 92 + "\n"
    output_string += "Total fine: " + str(total_fine) + "\n"
    output_string += "Total amount: " + str(total_amount) + "\n"
    output_string += "=" * 92 + "\n"
    output_string += "Final amount: " + str(final_total) + "\n"
    output_string += "=" * 92 + "\n"

    file_name = generate_unique_filename(mode, customer_name, customer_number)

    with open(file_name,"w") as file:
        file.write(output_string)
    print("\n" * 3 ,output_string)


def update_main_database(mode,rented_lands):
    """
    rent - return
    """

    land_data = read_land_data()
    
    for land in rented_lands:
        land_number = land['kitta']
        
        if land_number in land_data:
            if mode == "rent":
                land_data[land_number]['status'] = 'Not Available'
            else:
                land_data[land_number]['status'] = 'Available'

    with open('data.txt', 'w') as file:
        for land_number, details in land_data.items():
            line = str(land_number) + ',' + details['city'] + ',' + details['direction'] + ',' + str(details['anna']) + ',' + str(details['price']) + ',' + details['status'] + '\n'
            file.write(line)
