from operations import rent_operation,return_operation
from miscallaneous import greet_user,goodbye

def run():
    """
    The run function is the main function of our program. It contains The main logic of our program
    This function first shows the details to the user. 
    calls the rent operation funcion when the user enters 1,
    calls the return operation funcion when the user enters 2,
    calls the goodbye funcion when the user enters 3 and exits the program,
    """

    # display suitable greeting to the user
    greet_user()

    run_program = True
    while run_program:
        # initialize the user input   
        user_input = None 
        
        try:
            # ask the user to input a number
            user_input = int(input("Enter a number: "))

            if user_input == 1:
                # call the rent operation function when the user enters 1
                rent_operation()
            elif user_input == 2:
                # call the return operation function when the user enters 2
                return_operation()
            elif user_input == 3:
                # display a suitable goodbye message
                goodbye()
                # close the program
                run_program = False
            else:
                print("\nPlease choose a valid option! (1 or 2 or 3)\n")

        # validating the user input 
        except ValueError:
            print("\nPlease enter a valid input!\n")

run()
